# HackerOne Datasource for Grafana

This is a backend datasource to get data about payouts, earnings and reports from HackerOne.
